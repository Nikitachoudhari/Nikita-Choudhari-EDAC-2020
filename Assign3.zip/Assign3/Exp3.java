class Exp3
{
	public static void main(String jj[])
	{
	int j=3;
	int i= ++j + j++;
	System.out.println(i);
	}

}