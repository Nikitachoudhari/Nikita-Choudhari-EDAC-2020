class Exp1
{
	public static void main(String Arf[])
	{
	int AT='A';
	System.out.println(AT);
	AT++;
	System.out.println(AT);

	char Ab='A';
	System.out.println(Ab);
	Ab++;
	System.out.println(Ab);
	}

}