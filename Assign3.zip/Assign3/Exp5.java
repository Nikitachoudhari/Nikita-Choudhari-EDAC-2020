class Exp5
{
	static String str;
	static int b;
	static double d;
	static char c;
	static float f;
	static byte r;

	public static void main(String jj[])
	{
	
	System.out.println(str);
	System.out.println(b);
	System.out.println(c);
	System.out.println(d);
	System.out.println(f);
	System.out.println(c);
	}
}