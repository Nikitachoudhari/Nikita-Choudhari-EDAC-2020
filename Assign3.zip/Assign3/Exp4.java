class Exp4
{
	public static void main(String agd[])
	{
	byte b=10;
	b=(byte)(b*2);
	int c=b*2;
	System.out.println(b);
	System.out.println(c);


	boolean A=false , B=true , C;
	C=(A|B);
	System.out.println(C);

	//bitwise Logical Operator
	int x=42,y=15;
	int z=(x&y);
	System.out.println(z);
	System.out.println(x^y);
	System.out.println(x|y);	


	}

}