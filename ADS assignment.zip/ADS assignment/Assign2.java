//Assignment 2

import java.util.*;
/* 1. Array
class Test                    //container class
{	  Scanner sc = new Scanner(System.in);

	long [] arr = new long[100];
	int n;
	Test()
	{
		
		n=0;
	}

	 public void insert()
	{
		System.out.println("Enter the element to insert : ");
		long value = sc.nextLong();
		arr[n] = value;
		(n)++;
	} 
	
	public void delete()
	{
		System.out.println("Enter the element to delete : ");
		 long del = sc.nextLong();
		int i;
		 for( i=0 ; i<n ; i++)
			if(arr[i] == del)
			  break;
						
			if(i == n)
			System.out.println("Element is not found to delete..");
			
			else
			{
			for(int k = i ; k<n ; k++)
			 arr[k] = arr[k+1];
		
			n--;	
		       System.out.println("Element is deleted successfully.."); 
		        }
		
		
           }

	public void display()
	{
		if(n == 0)
		System.out.println("Array is Empty");

		else
		for(int i=0 ; i<n ; i++)
		System.out.print(arr[i]+"  ");

		System.out.println("");
	} 

}

class Assign2
{
	public static void main(String hh[])
	{	
	Test t1 = new Test();
	t1.insert();
	t1.insert();
	t1.display();

	t1.delete();
	t1.display();	
	}

}
*/
//=======================================================================================================
/* 2.  stack
class Stack
{
	int MAX = 10;
	int top = -1;
	int[] a = new int[MAX];
	
	
	boolean isEmpty()
	{
		if(top<0)
			return true;
		else 
			return false;
		
	}
	
	boolean isFull()
	{
		if(top >= MAX)
			return true;
		else 
			return false;
	}
	
	void push(int n)
	{
		if(top == (MAX-1))
		{
			System.out.println("Stack is overflow");
		}
		else
		{
			
			     top++;
			    a[top]=n;
		            System.out.println(n+" is pushed into stack ");
			
		}
	}
	
	void pop()
	{
		if(isEmpty())
		{
			System.out.println("Stack is Underflow");
		}	
		else
		{
			System.out.println(a[top]+" is poped from stack");
			top--;
		}
		
	}
	
	void quit()
	{
		System.exit(0);
	}
	
	void peek()
	{
		if (isEmpty()) {
			System.out.println("Stack Underflow");
			
			}
	     else {
		int x = a[top];
		System.out.println("Top Element is : "+ x);
		}
	}
	
	void traverse()
	{
		if(top<0)
		{
		System.out.println("Stack is Empty ");
		
		}
		else
		{
		System.out.print("Stack Elements : ");
		for(int i = 0 ; i<=top ; i++)
			System.out.print(a[i]+" ");
			System.out.println("");
		}
	}
}
public class Assign2
{
	public static void main(String args[])
	{
		Stack s1 = new Stack();
		Scanner sc = new Scanner(System.in);
		char test;
		
		do {
		System.out.println("1. push");
		System.out.println("2. pop ");
		System.out.println("3. peek ");
		System.out.println("4. Stack is Empty? ");
		System.out.println("5. Stack is Full? ");
		System.out.println("6. traverse ");
		System.out.println("7. Quit ");
		System.out.println("Enter your choice : ");
		int choice = sc.nextInt();
		
		
		
		switch(choice)
		{
		case 1:
			System.out.println("Enter the element to push into statck : ");
			int n = sc.nextInt();
			s1.push(n);
			break;
			
		case 2: s1.pop();
		break;
		
		case 3:  s1.peek();
		break;
		
		case 4: System.out.println( s1.isEmpty() );
		break;
		
		case 5: System.out.println(s1.isFull());
		break;
		
		case 6: s1.traverse();
		break;
		
		 case 7: s1.quit(); 
			break;
		
		default : System.out.println("Please enter valid choice ");
		}
		
		System.out.println("Do u want to continue : ");
		 test = sc.next().charAt(0);
		 
		}
		
		while(test =='y' || test == 'Y');
	
	}
}
*/
//===========================================================================================
/* 3.   Brackets
import java.util.*;
class Stack           
{
	int MAX = 10;
	int top = -1;
	char[] a = new char[MAX];
	
	
	public boolean isEmpty()
	{
		if(top<0)
			return true;
		else 
			return false;
		
	}
	
	boolean isFull()
	{
		if(top >= MAX)
			return true;
		else 
			return false;
	}
	
	public void push(char n)
	{
		if(top == (MAX-1))
		{
			System.out.println("Stack is overflow");
		}
		else
		{
			
			     top++;
			    a[top]=n;
		            //System.out.println(n+" is pushed into stack ");
			
		}
	}
	
	public char pop()
	{
		if(isEmpty())
		{
			System.out.println("Stack is Underflow");
			return 0;
		}	
		else
		{
			//System.out.println(a[top]+" is poped from stack");
			
			return a[top--];
		}
		
	}

	public char top()
	{
		if (isEmpty()) {
			System.out.println("Stack Underflow");
			return 0;
			}
	     else {
		char x = a[top];
		return x;
		}
	}


}
public class Assign2        //Single Bracket
{
	String str;
	Stack s1;

	Assign2(String s)
	{
		str = s;
		s1 = new Stack();
	}

	public int checkMatch()   //single type of brackets
	{
		for(int i=0 ; i<str.length() ; i++)
		{
			if(str.charAt(i) == '{')
			{
				s1.push(str.charAt(i));
			}
			else if(str.charAt(i) == '}')
			{
				if(s1.isEmpty())
				{
					System.out.println("Too many closing paras ");	
					return -1;
				}
				else
				s1.pop();	
			}

		}
		if(s1.isEmpty())
		{
			System.out.println("Bracket Balanced ");
			return 1;	
		}
		else
		{
			System.out.println("Bracket not Balanced");
			return 0;		
		}

	}

        String matchParenthisis(String str)   //multiple type of brackets
       {

       // Stack<Character> st = new Stack<Character> ();
        char[] ch = str.toCharArray();
        for (char c : ch) 
	{
            if (c == '{' || c == '[' || c == '(') 
	    {
                s1.push(c);
            } else {
                if (c == ']' && !s1.isEmpty() && s1.pop() == '[') {
                    continue;
                } else if (c == '}' && !s1.isEmpty() && s1.pop() == '{') {
                    continue;
                } else if (c == ')' && !s1.isEmpty() && s1.pop() == '(') {
                    continue;
                } else {
                    return "NO";
                }
            }
        }
        if (!s1.isEmpty()) {
            return "NO";
        }
        return "YES";
    }

	public static void main(String hh[])
	{
		Scanner sc = new Scanner(System.in);		

		System.out.println("Single brackets");
		System.out.println("Enter two String : ");
		String str = sc.next();
		String str1 = sc.next();

		Assign2 b1 = new Assign2(str);
		b1.checkMatch();

		Assign2 b2 = new Assign2 (str1);
		b2.checkMatch();

		System.out.println("Multiple brackets");
		System.out.println("Enter two String : ");
		String s1 = sc.next();
		String s2 = sc.next();

		Assign2 b3 = new Assign2(s1);
		System.out.println(b3.matchParenthisis(s1));

		Assign2 b4 = new Assign2 (s2);
		System.out.println(b4.matchParenthisis(s2));
	}

}
*/
//=========================================================================================================

/* 4.  stack generics
class MyGenericsStack<T extends Object> {
 
    private int stackSize;
    private T[] stackArr;
    private int top;
    
    @SuppressWarnings("unchecked")
    public MyGenericsStack(int size) {
        this.stackSize = size;
        this.stackArr = (T[]) new Object[stackSize];
        this.top = -1;
    }
 
    public void push(T entry){
        if(this.isStackFull()){
            System.out.println(("Stack is full. Increasing the capacity."));
            this.increaseStackCapacity();
        }
        System.out.println("Adding: "+entry);
        this.stackArr[++top] = entry;
    }
 
   
    public T pop() throws Exception {
        if(this.isStackEmpty()){
            throw new Exception("Stack is empty. Can not remove element.");
        }
        T entry = this.stackArr[top--];
        System.out.println("Removed entry: "+entry);
        return entry;
    }
     
   
    public T peek() {
        return stackArr[top];
    }
 
    private void increaseStackCapacity(){
         
        @SuppressWarnings("unchecked")
        T[] newStack = (T[]) new Object[this.stackSize*2];
        for(int i=0;i<stackSize;i++){
            newStack[i] = this.stackArr[i];
        }
        this.stackArr = newStack;
        this.stackSize = this.stackSize*2;
    }
     
    
    public boolean isStackEmpty() {
        return (top == -1);
    }
 
   
    public boolean isStackFull() {
        return (top == stackSize - 1);
    }
     
   
}
class Assign2
{
	 public static void main(String a[])
	{
       		 MyGenericsStack<String> stringStack = new MyGenericsStack<String>(2);
        	stringStack.push("java2novice");
	
       		 MyGenericsStack<Integer> integerStack = new MyGenericsStack<Integer>(2);
       		 integerStack.push(23);
        }

}
*/

//=============================================================================================
/* 5.  Linear Queue
class Queue
{
	int front =-1; int rear = -1 ; 
	int size = 10;
	int arr[] = new int[size];


	boolean isEmpty() 
	{
		if(front == -1 && rear == -1 || front==rear)
		return true;
		else 
		return false;
	}

	boolean isFull() 
	{
		if(rear >= size)
		return true;
		else 
		return false;
	}

	void enqueue(int item)
	{
		if(isFull())
		{
			System.out.println("Queue is Full..");
		}
		else
		{
			arr[++rear] = item;      //rear = 0
			//rear++;
			System.out.println(item+ " enqueued to queue");
		}

	}

	void dequeue()
	{
		if(isEmpty())
		{
			System.out.println("Queue is Empty..");
		}
		else
		{
			int item = arr[++front] ;
			//front++;
			System.out.println(item+ " dequeued from queue");
		}

	}

	void traverse()
	{
		if(isEmpty())
		System.out.println("Queue is Empty");
		else
		{
			int a1 = front , b1 = rear;
			do{
				System.out.print(arr[++a1]+" ");
			  }while(a1 != b1);	
			System.out.println("");
		}
	}
	
	void quit()
	{
		System.exit(0);
	}

}

class Assign2
{
	public static void main(String kk[])
	{
		Queue q1 = new Queue();
		Scanner sc = new Scanner(System.in);
		char test;
		
		do {
		System.out.println("1. enqueue");
		System.out.println("2. dequeue ");
		System.out.println("3. Front item  ");
		System.out.println("4. rear item ");
		System.out.println("5. queue is Empty? ");
		System.out.println("6. queue is Full? ");
		System.out.println("7. Traverse ");
		System.out.println("8. Quit ");
		System.out.println("Enter your choice : ");
		int choice = sc.nextInt();
		
		
		
		switch(choice)
		{
		case 1:
			System.out.println("Enter the element to add into queue : ");
			int n = sc.nextInt();
			q1.enqueue(n);
			break;
			
		case 2: q1.dequeue();
		break;
		
		case 3: 
			System.out.println(q1.arr[q1.front]); 
		break;
		
		case 4: System.out.println( q1.arr[q1.rear] );
		break;
		
		case 5: System.out.println(q1.isEmpty());
		break;
		
		case 6: System.out.println(q1.isFull());
		break;
		
		case 7: q1.traverse(); 
			break;

		case 8: q1.quit(); 
			break;
		
		default : System.out.println("Please enter valid choice ");
		}
		
		System.out.println("Do u want to continue : ");
		 test = sc.next().charAt(0);
		 
		}
		
		while(test =='y' || test == 'Y');

	}

}
*/
//====================================================================================================================

/*  6.Circular Queue

class Queue
{
    	
    	int rear,front,size;
    	int[] arr;

    	Queue(int size)
   	 {
       		 rear = front = -1;
        	this.size = size;
        	arr = new int[size];
   	 }

    	boolean isEmpty()
    	{
       		 return (front==rear);
        }

        boolean isFull()
        {
       		 return ((front == -1 && rear == size-1)||(rear == (front -1)%(size-1)));
    	}
	
  	  boolean enqueue(int item)
   	 {
       		 if(isFull())
        	{
            		System.out.println("Queue is full");
            		return false;
        	}
       		 else
       		 {
           		 if(rear == size-1  )  //&& front != 0
           		 {
                		rear=-1;
				
           		 }
           	 	rear++;
            		arr[rear]=item;
           		 System.out.println("Item enqueued to Queue = "+item);
            		return true;
        	}
    	}
	
   	 boolean dequeue()
   	 {
        	if(front==rear)
       		 {
           		 System.out.println("Queue is empty");
           		 return false;
       		 }
       		 else
       		 {
          	 	 int item = arr[++front];
            		System.out.println("Item Dequeued from Queue = "+item);
           	       return true;
      		  }
   	 }

       void traverse()
      {
           if( front == rear)
            System.out.println("Queue is empty");		
           else{	   
		int a1 =front ; int  b1 = rear;
		
			do
			{
				if( a1 == size-1 )
		                a1 = -1;
				System.out.print(arr[++a1]+" ");
			}while(a1 != b1);
			//System.out.print(arr[a1]);
			System.out.println("");
		}

      }

	void quit()
	{
		System.exit(0);
	}	

}

public class Assign2
{
    	public static void main(String[] args)
    	{
       		Scanner sc=new Scanner(System.in);
        	System.out.println("Enter size of Queue : ");
        	  int size=sc.nextInt();
       		 Queue q1 = new Queue(size);
             
		
                 int choice; char ch;
		System.out.println(" Welcome to Circular Queue Data Structure ");
		do
		{
			System.out.println("1. enqueue ");
			System.out.println("2. dequeue ");
			System.out.println("3. Queue is Full ? ");
			System.out.println("4. Queue is Empty ? ");
			System.out.println("5. traverse ");
			System.out.println("6. Exit ");	
			System.out.println("Enter your choice :  ");
		choice = sc.nextInt();
		switch(choice)
		{
			case 1 : System.out.println("Enter the element : ");
				int item = sc.nextInt();
				q1.enqueue(item);
			break;

			case 2 : q1.dequeue();
			break;

			case 3 : System.out.println("Queue is Full : "+q1.isFull());
			break;

			case 4 : System.out.println("Queue is Empty : "+q1.isEmpty());
			break;

			case 5 : q1.traverse();
			break;

			case 6 : q1.quit();
			break;

			default : System.out.println("Enter the valid choice");

		}
		System.out.println("Do you want to continue..");
		ch = sc.next().charAt(0);
		}
		while( (ch == 'y') || (ch =='Y') );


    }
}
*/
//==================================================================================================================

//7. Doubly Queue
/*
import java.util.*; 
  
class Deque
{
	int front , rear;
	int size = 10;	
	int arr[] = new int[size];
	
	Deque()
	{
		front = rear = -1;
	}

	boolean isEmpty()
	{
		return (front == -1 && rear == -1);
	}

	void addToFront(int data)
	{
		
		if(isEmpty())
		{
			rear++;   //rear =0
			arr[++front] = data;   //front= 0
			System.out.println(arr[front]+" added to Queue");
			return;
		}
		else 
		{
			if(front == 0)
			System.out.println("not inserted...front pointer reach to limit");
			else
			{arr[--front] = data;
			System.out.println(arr[front]+" added to Queue");}
		}
		

	}

	void addToRear(int data)
	{
		if(rear == size-1)
		System.out.println("not inserted...rear pointer reach to limit");
		else
		{
			arr[++rear] = data;
			System.out.println(arr[rear]+" added to Queue");
		}	

	}

	void deleteFront()
	{
		if(isEmpty())
		System.out.println("Queue is empty");
		else
		{
			int data = arr[front];
			front++;
			System.out.println(data+" dequeued from Queue");
		}
	}
	
	void deleteRear()
	{
		if(isEmpty())
		System.out.println("Queue is empty");
		else if(front == 0 && rear == 0)
		{
			int data = arr[rear];
			rear--; front--;
			System.out.println(data+" dequeued from Queue");		
		}
		else
		{
			int data = arr[rear];
			rear--;
			System.out.println(data+" dequeued from Queue");
		}
	}

	void traverse()
	{
		if(isEmpty())
		System.out.println("Queue is empty");
		else if (front > rear)
		System.out.println("Queue is empty");
		else
		{
			int a1 = front, b1 = rear;
			while(a1 != b1)
			{
				System.out.print(arr[a1]+" ");
				a1++;
			}
			System.out.print(arr[b1]+" ");
			System.out.println(" ");
		}
	}
}
class Assign2
{
	public static void main(String hh[])
	{  Scanner sc = new Scanner(System.in);
		Deque a1 = new Deque();

		int choice; char ch;
		System.out.println(" Welcome to Double ended Queue Data Structure ");
		do
		{
			System.out.println("1. add to front ");
			System.out.println("2. add to rear ");
			System.out.println("3. Delete from front ");
			System.out.println("4. delete from rear ");
			System.out.println("5. queue is empty ? ");
			System.out.println("6. traverse ");	
			System.out.println("Enter your choice :  ");
		choice = sc.nextInt();
		switch(choice)
		{
			case 1 : System.out.println("Enter element to insert : ");	 
				a1.addToFront( sc.nextInt() );
			break;

			case 2 : System.out.println("Enter element to insert : ");
				a1.addToRear(sc.nextInt());
			break;

			case 3 : a1.deleteFront();
			break;

			case 4 :a1.deleteRear();
			break;

			case 5 : System.out.println("Queue is Empty : "+a1.isEmpty());
			break;
		
			case 6 :a1.traverse();
			break;

			default : System.out.println("Enter the valid choice");

		}
		System.out.println("Do you want to continue..");
		ch = sc.next().charAt(0);
		}
		while( (ch == 'y') || (ch =='Y') );

	}
} 

*/
//===============================================================================================================

/* 8.Singly Linked List
class Node
{
	int data;
	Node next;

	Node(int data)
	{
		this.data=data;
		next = null;
	}

}
class Assign2
{
	Node head;
	int length;

	LinkedListDemo()
	{
		length = 0;
	}

	//insertion of Node
	void insertBeg(int data)
	{
		Node newNode = new Node(data);
		if(head == null)
		head = newNode;
		else
		{
			newNode.next = head;
			head = newNode;
		}
		length++;
	}
	void insertMid(int data , int pos)
	{
		Node newNode = new Node(data);
		if(pos == 1)
		insertBeg(data);
		else
		{
			Node temp = head;
			for(int i=1 ; i<pos-1 ; i++)
			temp = temp.next;
		
			newNode.next = temp.next;
			temp.next= newNode; 

		}
		length++;

	}
	void insertEnd(int data)
	{
		Node newNode = new Node(data);
		if(head == null)
		head = newNode;
		else
		{
			Node temp = head;
			while(temp.next != null)
			temp = temp.next;

			temp.next=newNode;

		}
		length++;
	}

	//Deletion of node
	void deleteBeg()
	{
		if(length == 0)
		System.out.println("List is empty");
		else
		head = head.next;
		length--;
	}
	void deleteEnd()
	{
		if(length == 0)
		System.out.println("List is empty");
		else
		{
			Node temp=head;
			while(temp.next.next != null)
			temp=temp.next;

			temp.next=null;
		}
		length--;
	}
	void deleteMid(int pos)
	{
		if(length == 0)
		System.out.println("List is empty");

		if(pos == 1 )
		 deleteBeg();
		else 
		{
			Node temp = head;
			for(int i=1 ; i<pos-1 ; i++)
			temp= temp.next;

			temp.next = temp.next.next;
			
		}
		length--;
	}

	void display()
	{
		Node temp = head;
		while(temp.next != null)
		{
			System.out.print(temp.data+" ");	
			temp = temp.next;
		}
		System.out.print(temp.data);
		System.out.println("");	
	}

	public static void main(String hh[])
	{
		LinkedListDemo d1 = new LinkedListDemo();
		d1.insertBeg(10);
		d1.insertBeg(50);
		d1.insertBeg(22);
		System.out.println(" insert at beg");
		d1.display();

		d1.insertEnd(99);
		System.out.println(" insert at end");
		d1.display();	

		d1.insertMid(20 , 4 );
		System.out.println(" insert mid at 4 ");
		d1.display();	

		d1.insertMid(5 , 1 );
		System.out.println(" insert mid at 1 ");
		d1.display();

		d1.deleteEnd( );
		System.out.println(" delete at end ");
		d1.display();

		d1.deleteBeg( );
		System.out.println(" delete  at beg ");
		d1.display();

		d1.deleteMid( 3);
		System.out.println(" delete  mid at 3 ");
		d1.display();

		d1.deleteEnd();
		System.out.println(" delete at end ");
		d1.display();

		d1.deleteEnd();
		System.out.println(" delete at end ");
		d1.display();

		d1.deleteEnd();
		System.out.println(" delete at end ");
		d1.display();

		


	}
}	
*/
//=========================================================================================================================
/* 9.doubly Linked List
class Node
{
	int data;
	Node prev,next;

	Node(int data)
	{
		this.data = data;
		prev=next=null;
	}		

}
class DoublyLinked  //container class
{
	Node start;
	int length;
	DoublyLinked()
	{
		length = 0;
	}

	//insertion of node 	
	void insertBeg(int data)
	{
		Node newNode = new Node(data);
		if(start == null)
		start = newNode;
		else
		{
			newNode.next = start;
			start.prev = newNode;
			start = newNode;

			
		}
		     length++;
		   System.out.println("element inserted ");
		
		
	}
	void insertEnd(int data)
	{
		Node newNode = new Node(data);
		if(start == null)
		insertBeg(data);
		else
		{
			Node temp=start;
			while(temp.next != null)
			temp = temp.next;
			
			temp.next=newNode;
			newNode.prev=temp;

			length++;
			System.out.println("element inserted");
		}	
			
	}
	void insertMid(int data , int pos) 
	{
		if(pos == 1)
		insertBeg(data);
		
		else if(pos > length)
		insertEnd(data);
		else
		{
			Node newNode = new Node(data);
			Node temp = start;
			int i=1;
			while(temp.next != null)
			{
				i++;
				
				if(pos == i)
				 break;
				temp = temp.next;
			        
			}
			newNode.next = temp.next;
			newNode.prev=temp;
			temp.next = newNode;
			temp.next.prev=newNode;
			length++;
		System.out.println("element inserted");
		}	

	}

	//deletion of nodes
	void deleteBeg()
	{
		if(start == null)
		System.out.println("list is empty");
		else if(start.next == null)
		{start = null;
		System.out.println("element deleted");}
		else
		{
			start = start.next;
			start.prev = null;
		length--;System.out.println("element deleted");
		}
		
	}
	void deleteEnd()
	{
		if(start == null)
		System.out.println("list is empty");
		else if(start.next == null)
		{start = null;
		System.out.println("element deleted");}
		else
		{
			Node temp=start;
			while(temp.next.next != null)
			{temp=temp.next;}

			temp.next.prev=null;
			temp.next=null;
			
		length--;	System.out.println("element deleted");
		}
		
	}
	void deleteMid(int pos)
	{

		

		if(pos == 1)
		deleteBeg();
		else if(pos > length)
		deleteEnd();
		else
		{
			Node temp = start;
			int i=1;
			while(temp.next != null)
			{
				i++;
				
				if(pos == i)
				 break;
				temp = temp.next;
			        
			}
			temp.next = temp.next.next;
			temp.next.prev=temp;
			length--;System.out.println("element deleted");	
		}
	}

	//display List
	void displayForward()
	{
		if(start == null)
		System.out.println("List is empty");
		else
		{
			Node temp = start;
			while(temp.next != null)
			{
				System.out.print(temp.data+" ");
				temp = temp.next;
			}
			System.out.print(temp.data);
			System.out.println("");
		}
		
	}
	void displayBackward()
	{
		if(start == null)
		System.out.println("List is empty");
		else
		{
			Node temp=start;
			while(temp.next != null)
			temp = temp.next;
		
			while(temp.prev != null)
			{
				System.out.print(temp.data+" ");
				temp = temp.prev;
			}
			System.out.print(temp.data);
			System.out.println();
		}
	}
			
}
class Assign2   //driver class
{
	public static void main(String hh[])
	{
		DoublyLinked d1 = new DoublyLinked();
		  	
		 Scanner sc = new Scanner(System.in);
		

		int n; char ch ; 
		
		System.out.println(" Welcome to Doubly Linked list Data Structure ");
		do
		{
			System.out.println("1. Insert at beg");
			System.out.println("2. Insert at end ");
			System.out.println("3. Insert at mid ");
			System.out.println("4. Delete from beg ");
			System.out.println("5. Delete from end ");
			System.out.println("6. Delete from mid ");
			System.out.println("7. display forward ");
			System.out.println("8. display backward ");	
			System.out.println("Enter your choice :  ");
		n = sc.nextInt();
		switch(n)
		{  int  data , pos ;
			case 1 :System.out.println("Enter the element to insert: "); 
				 data =sc.nextInt();
				d1.insertBeg(data); 
			break;

			case 2 : System.out.println("Enter the element to insert: "); 
				 data =sc.nextInt();
				d1.insertEnd(data); 
			break;

			case 3 : System.out.println("Enter the element to insert and position : "); 
				  data =sc.nextInt();
				  pos = sc.nextInt();
				 d1.insertMid(data , pos); 
			break;

			case 4 : d1.deleteBeg();
			break;

			case 5 : d1.deleteEnd();
			break;

			case 6 :System.out.println("Enter the position to delete element : ");
				pos = sc.nextInt();	
				 d1.deleteMid(pos);
			break;

			case 7 : d1.displayForward();
			break;

			case 8 : d1.displayBackward();
			break;

			default : System.out.println("Enter the valid choice");

		}//switch
		System.out.println("Do you want to continue..");
		ch = sc.next().charAt(0);
		}//do
		while( (ch == 'y') || (ch =='Y') );

	}

}
*/

//========================================================================================================================= 
//10.using link list         stack, queue And its operatons
//Implementing stack using linked list 
/*
class Node       
{
	int data;
	Node next;

	Node(int data)
	{
		this.data = data;
		next = null;
	}	

}
class Stack
{
	Node top ;

	Stack()
	{
		top = null;
	}

	boolean isEmpty()
	{
		if(top == null)
		return true;
		else
		return false;
	}

	void push(int data)
	{
		Node newNode = new Node(data);
		
		if(top == null)
		top = newNode;
		else
		{
		newNode.next=top;
		 top = newNode; 
		}
		System.out.println(data+" pushed into stack");
	}

	void pop()
	{
		if(isEmpty())
		{
			System.out.println("Stack is empty");
		}
		else{
		System.out.println(top.data+" item poped from stack");	
		top = top.next;
		}
	}
	
	void Peek()  
        {  
     		if (top == null)  
   	 	{  
         		System.out.println("Stack Underflow.");  
        		 return;  
    		 }  
  
    		 System.out.println(top.data+" is on the top of Stack");  
 	}  
	
	void traverse()
	{
		if(top == null)
		{
			System.out.println("Stack is empty");
		}
		else
		{
			Node temp = top;
			while(temp.next != null)
			{System.out.print(temp.data +" ");
			temp = temp.next;}
			System.out.print(temp.data);
			System.out.println("");
		}
	}	
	
}

class Assign2
{
	public static void main(String hh[])
	{
		Stack s1 = new Stack();
		s1.push(21);
		s1.push(58);
		s1.pop();
		s1.pop();
		s1.pop();
		s1.push(55);
		System.out.println("Empty : "+s1.isEmpty());
		s1.push(44);
		s1.traverse();
		s1.Peek();
	}

}
*/
//========================================================================================================================
/*        Implementing Queue using Linked list
    
class Node
{
	int data;
	Node next;

	Node(int data)
	{
		this.data =data;
		next =null;

	}

}
class Queue
{
	Node front , rear;
	
	boolean isEmpty()
	{
		return (front == rear == null);
	}

	void enqueue(int data)
	{
		Node newNode = new Node(data);
		if(rear == null)
		{
			rear = newNode;
			front = rear;
		}
		else
		{
			rear.next = newNode;
			rear = newNode;
		}
		System.out.println(rear.data +" enqueued to Queue");	
	}
	
	void dequeue()
	{
		if(front == null  )
		System.out.println("Queue is Empty");
		else
		{
			System.out.println(front.data +" dequeued from Queue");
			front= front.next;

		}
		
	}

	void traverse()
	{
		if(isEmpty())
		System.out.println("Queue is Empty");
		else
		{
			Node temp = front;
			while(temp != rear)
			{System.out.print(temp.data+" ");
			temp =temp.next;	}
			System.out.print(rear.data+" ");
			System.out.println(" ");
		}
	}	

}
class Assign2
{
	public static void main(String hh[])
	{
		Queue q1= new Queue();

		q1.enqueue(12);
		q1.enqueue(80);
		q1.traverse();
		q1.dequeue();
		q1.enqueue(45);
		q1.enqueue(11);
		q1.traverse();

		q1.dequeue();
		q1.dequeue();
		q1.dequeue();

		q1.dequeue();	

	}

}
*/