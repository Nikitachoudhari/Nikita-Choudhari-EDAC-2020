import java.util.Scanner;
/*
//1. WAP to find factorial of number using iteration and recursion
class Assign1
{
	static int fibo(int n)   //iteration
	{	
		int fact = 1;
		
		for(int i=1 ; i<=n ; i++)
		fact = fact*i;
		return fact;
			
	}
	static int factorial(int n)     //recursion
	{
		if(n == 0)
		return 1;
		else
		return n*factorial(n-1);
	}
	public static void main(String hh[])
	{
		int fact =1;
		int fact1 =1;
		Scanner s =new Scanner(System.in);
		System.out.println("Enter the number for factorial : ");
		int n = s.nextInt();

		fact = factorial(n);   //fact using recursion
		System.out.println("factorial of "+n+ " is "+fact+" using recurssion.");

		fact1 = fibo(n);   //fact using iteration
		System.out.println("factorial of "+n+ " is "+fact+" using iteration");	

		
	}
}
*/
//===========================================================================================

//2. WAP to print Fibonacci series using iteration and recursion.
public class Assign1
{
	int fibo(int n)  
	{
		int f = 0;
		int a = 0;
		int b = 1 ; 
		
		if(n == 1)
			return a;
		
		else if(n == 2)
			return b;
		
		else
		{
			for(int i = 0 ; i<n-2 ; i++)     //iteration
			{
				f = a+b;
				a = b;
				b = f;
	
			}
		}
		return f;
	}
	
	static int fibo1(int n)        //recurssion.
    { 
		if(n == 1)
	     return 0;
		
	   else if (n == 2 || n == 3) 
       return 1;
		
       else 
      return fibo1(n-1) + fibo1(n-2); 
    }
	
	public static void main(String hh[])
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the no. for fibonacci series : ");
		int n = s.nextInt();
		
		Assign1 a1=new Assign1();
		System.out.println("Fibonacci using iteration : ");
		 System.out.println(a1.fibo(n));   //iteration call
		
		System.out.println("Fibonacci using recurssion : ");
		 System.out.println(fibo1(n)); 
	}
}

//===============================================================================
/*
//3. WAP to find sum of n  number using iteration and recursion

class Assign1
{
	static int fun(int n)           //using iteration
	{
		int sum=0;
		for (int i = 1 ; i<=n ;i++)
			sum+=i;
		return sum;
		
	}
	
	static int fun1(int n)                //using Recurssion.
	{
		if(n == 1)
			return 1;
		else
		return n+fun1(n-1);
	}
	
	public static void main(String hh[])
	{	
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number : ");
		int n = s.nextInt();
		
		System.out.println("Sum of number using iteration : ");
		System.out.println(fun(n));
		
		System.out.println("Sum of number using Recursion : ");
		System.out.println(fun1(n));
		
	}

}
*/
//===================================================================================
//4. Tower of Hanoi problem using recursion.
/*
class Assign1
{
	public static void tower(int disk , char a , char b , char c)
	{	
		if(disk == 1)
		{
			System.out.println("Disk 1 from "+a+" to "+c);
		}
		else
		{
			tower(disk-1 , a , c , b);
			System.out.println("Disk "+disk+" from "+a+" to "+c);
			tower(disk-1 ,  b , a ,  c);
		}
		
	}
	
	public static void main(String ff[])
	{
		int disk = 3;
		char a ='A' , b = 'B' , c = 'C';
		
		tower(disk , a , b , c);
		
	}
}

*/



//===================================================================================
//5. WAP to find the largest number among 3 int, float, double then convert the same example using Generic classes
/*
class CompDemo
{
	public static void main(String jj[])
	{
		int a=10,b=23,c=44;

		if(a>=b && a>=c)
		System.out.println("a is greater.");

		else if(b>=c)
		System.out.println("b is greater.");

		else
		System.out.println("c is greater.");
		
	}

}
*/

//=====================================================================
/*
class CompDemo
{
	public static void main(String jj[])
	{
		float a=100.23f, b = 53.64f, c = 89.457f;

		if(a>=b && a>=c)
		System.out.println("a is greater.");

		else if(b>=c)
		System.out.println("b is greater.");

		else
		System.out.println("c is greater.");
		
	}

}
*/
//==========================================================================
/*
class CompDemo
{
	public static void main(String jj[])
	{
		double a=10.362145 , b = 232.336 , c = 44.00;

		if(a>=b && a>=c)
		System.out.println("a is greater.");

		else if(b>=c)
		System.out.println("b is greater.");

		else
		System.out.println("c is greater.");
		
	}

}
*/
//============================================================================
/*
class  CompDemo 
{
	public static <T extends Comparable<T>> void fun(T a , T b , T c)      //generic function
	{
		if( a.compareTo(b) >= 0  &&  a.compareTo(c) >= 0 )
			System.out.println("a is greater.");

		else if( b.compareTo(c) >= 0 )
			System.out.println("b is greater.");

		else
		System.out.println("c is greater.");
	}
	
	public static void main(String hh[])
	{
		
		
		Integer a = new Integer(10);
		Integer b = new Integer(2);
		Integer c = new Integer(62);
		
		fun(a , b, c);
		
	}
}
*/










