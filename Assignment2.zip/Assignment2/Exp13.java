//Hollow Full Pyramid

class Exp13
{
	public static void main(String hh[])
	{
          int  i, j;
	

	for( i=1 ; i<=6 ; i++)
	{
	  for( j=i ; j<6 ; j++)
	  {
	  System.out.print(" ");
	  }

	  for( j=1; j<=i; j++)
	  {
	   if( j==1 || i==6)
	   {
	   System.out.print("* ");
	   }
	   else
	   {
	   System.out.print(" ");
	   }
	}	
	
	for(j=1; j<=i; j++)
	{
	  if(j==i-1 && j<6-1)
	  {
	  System.out.print("* ");
	  }
	  else
	  {
	  System.out.print(" ");
	  }
	  }
	   System.out.print("\n");
	}
   }
}