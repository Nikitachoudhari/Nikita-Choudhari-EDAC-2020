//Hollow Inverted Half Pyramid

class Exp10
{
	public static void main(String hh[])
	{
		int  i, j;
 	for( i=1 ; i<=6 ; i++)
	{
	for(j=i ; j<=6 ; j++)
	{
	  if ( i==1 || j==6 || j==i)
	  System.out.print("* ");
	  else
	  System.out.print("  ");
	}
	System.out.println();
	}


	}
}