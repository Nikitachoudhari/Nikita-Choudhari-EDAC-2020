//pyramid pattern-4	



class Exp4

{
	
	public static void main(String hh[])
	
        {   
	
	        int i , j ;
	
	
	
               for( i=1 ; i<=9 ; i++)
	
	       {	
	  
                 for( j=1 ; j<=(9-i) ; j++)
	 
                 {
	   
                  System.out.print("  ");
	  
                 }

	  
	  
                 for( j=1 ; j<=i ; j++)
	  
                 {
	  
                  System.out.print(j+" ");
	 
                 }

	  
	  
                 for( j=i-1 ; j>=1 ; j--)
	  
                 {
	   
                 System.out.print(j+" ");
	 
                 }

	 
	
                 System.out.print("\n");
	
               }
	
	
         }
	
	

}
