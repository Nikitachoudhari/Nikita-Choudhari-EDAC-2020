//Half Pyramid

class Exp8
{
	public static void main(String hh[])
	{
	int i , j ;
	
	
	
	for( i=1 ; i<=6 ; i++)
	{	
	 for( j=1 ; (i+1)>j ; j++)
	 {
	   System.out.print("* ");
	 }
	 System.out.print("\n");
	}
	
	}
	
	
}
