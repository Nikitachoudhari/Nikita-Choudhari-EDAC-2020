//pyramid pattern-5	



class Exp5

{
	
	public static void main(String hh[])
	
        {   
	
	        int i , j ;

	
	
int space=20;	
               for( i=1 ; i<=9 ; i++)
	
	       {	
	  
                 for( j=1 ; j<=space ; j++)
	 
                 {
	   
                  System.out.print(" ");
	  
                 }


	  
	  
                 for( j=i ; j>1 ; j--)
	  
                 {
	  
                  System.out.print((10-j)+" ");
	 
                 }

		space--;
		space--;
	  
	  
                 for( j=1 ; j<=i ; j++)
	  
                 {
                    System.out.print((10-j)+" ");

		  }

	 
	
                 System.out.print("\n");
	
               }
	
	
         }
	
	

}
