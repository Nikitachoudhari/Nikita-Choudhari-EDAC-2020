//Inverted pyramid pattern-6

class Exp6
{	
      
	public static void main(String hh[])
	{
        
             
 
	for(int i=9 ; i>0 ; i--)
               {
	               
                        for(int j=0 ; j<9-i ; j++)
                       {
                               System.out.print(" ");
                       }
                       
                        for(int j=0 ; j<i ; j++)
                       {
                               System.out.print("* ");
                       }
                      System.out.println();
               }         
	}
}