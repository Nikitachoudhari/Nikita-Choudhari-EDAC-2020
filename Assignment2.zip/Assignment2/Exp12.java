//Inverted Full Pyramid

class Exp12
{
	public static void main(String hh[])
	{
	for(int i=6 ; i>=1 ; i--)
	{
           for(int j=5 ; j>=i ; j--)
	   {
	   System.out.print(" ");
	   }
	     for(int j=1 ; j<=i ; j++)
            {
	    for(int k=i ; k<=i ; k++)
            {
	     System.out.print(" *");
	    }
	   }	
             System.out.println("");
	}
	}
}