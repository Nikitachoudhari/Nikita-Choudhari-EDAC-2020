//pyramid pattern-2

class Exp2
{
      public static void main(String hh[])
      {
	for(int i=1 ; i<=9 ; i++)
	{
           for(int j=8 ; j>=i ; j--)
	   {
	   System.out.print(" ");
	   }
	     for(int j=1 ; j<=i ; j++)
            {
	    for(int k=i ; k<=i ; k++)
            {
	     System.out.print(" "+j);
	    }
	   }	
             System.out.println("");
	}
    }
}