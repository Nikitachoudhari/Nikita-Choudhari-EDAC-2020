class Employee
{
	int a;
	void display(int a)
	{
	a=a;
	System.out.println(a);
	}
	
}

class Test
{
	public static void main(String hj[])
	{
	Employee e=new Employee();
	e.display(10);
	
	}

}


