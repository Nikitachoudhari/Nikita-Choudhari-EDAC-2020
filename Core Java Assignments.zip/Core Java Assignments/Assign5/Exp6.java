//6.Print the third-largest number in an array without sorting it  Input: [ 24,54,31,16,82,45,67] Output: 54 (82 and 67 are the largest and second-largest) 
 
 class Exp6
{
	public static void main(String hh[])
	{
	
	}

}