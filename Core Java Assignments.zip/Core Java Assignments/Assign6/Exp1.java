//1)WAP to define a class Student with attributes rollno, name , marks accept data for 2 objects and display them.


class Student
{
	int rollno;
	String name;
	double marks;

	Student(int x,String y,double z)
	{
	rollno=x;
	name=y;
	marks=z;
	}	

	void display()
	{
	System.out.println("Roll Number is : "+rollno);
	System.out.println("Name is : "+name);
	System.out.println("Marks is : "+marks);
	
	}
}
class Exp1
{
	public static void main(String hh[])
	{
	Student s=new Student(1,"Ram",67.98);
	Student s1=new Student(2,"Shyam",98.7);
	s.display();
	s1.display();
	}
}