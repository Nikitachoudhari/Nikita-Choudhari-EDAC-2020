//6)Write a program Complex number to add the real and imaginary part for 2 complex numbers

class ComplexNumber
{
	double real,img;

	ComplexNumber(double r,double i)
	{
	real=r;
	img=i;
	
	}

	void add(ComplexNumber s1,ComplexNumber s2)
	{
	real=s1.real+s2.real;
	img=s1.img+s2.img;
	
	}

}
class Exp6
{
	public static void main(String hh[])
	{
	ComplexNumber c1=new ComplexNumber(5,45.9);
	ComplexNumber c2=new ComplexNumber(33.1,560);

	ComplexNumber c3=new ComplexNumber(0,0);
	c3.add(c1,c2);
	System.out.println("Sum is : Real = "+c3.real+" Imaginary : "+c3.img);
	
	}

}

