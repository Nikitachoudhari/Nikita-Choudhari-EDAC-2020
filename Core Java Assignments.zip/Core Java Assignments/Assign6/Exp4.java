//4)WAP to define a class Employee with attributes id, name ,designation  accept data for 5 objects and display employee details whose designation is Manager.

class Employee
{
	int employeeId;
	String name;
	String designation;
	
	Employee(int id,String nm,String dig)
	{
	employeeId=id;
	name=nm;
	designation=dig;
	}
	void display()
	{
	System.out.println("Employee Id : "+employeeId);
	System.out.println("Name of Employee : "+name);
	System.out.println("Designation : "+designation);
	}
	

}
class Exp4
{
	public static void main(String hh[])
	{
	Employee e[] = new Employee[5];
	e[0]=new Employee(23,"Nikita","Professor");	
	e[1]=new Employee(67,"Pornima","Manager");
	e[2]=new Employee(33,"Lucky","Assistant");
	e[3]=new Employee(66,"Pinki","Junior Enginer");
	e[4]=new Employee(12,"Sayali","Employee");
	
	//e[0].display();
	for(int i=0 ;i<5 ;i++)
	{
	if(e[i].designation.equals("Manager"))    //str1.equals(str2)
	{
	e[i].display();
	}
	}

	}
}