//3)WAP to define a class Bank accept customerid, name, balance write method  to perform deposit, checkbal, withdraw keep min balance 1000.

import java.util.*;
class Bank
{
	int customerid;
	String name;
	double balance=1000;
	Scanner s=new Scanner(System.in);
	void accept()
	{
	System.out.println("Enter the customerid : ");
	customerid=s.nextInt();
	System.out.println("Enter the name of Customer : ");
	name=s.next();
	System.out.println("Enter the balance of Customer : ");
	balance=s.nextDouble();
	}
	
	void deposit()
	{
	System.out.println("Enter the amount to deposit : ");
	double amt=s.nextDouble();
	balance=balance+amt;
	System.out.println("Total Balance : "+balance);	
	}

	void checkbal()
	{
	System.out.println("Customer Id : "+ customerid);
	System.out.println("Name of Customer : "+ name);
	System.out.println("Bank Balance : "+ balance);
	}
	void withdraw()
	{
	System.out.println("Enter the amount to withdraw : ");
	double amt=s.nextDouble();
	balance=balance-amt;
	System.out.println("Total Balance : "+balance);	
	}

}


class Exp3
{	
	public static void main(String hh[])
	{char decide;
	Scanner s=new Scanner(System.in);
	Bank b1=new Bank();
	do
	{
		System.out.println("1. Accept data"); 
		System.out.println("2. Deposit data ");
		System.out.println("3.Check Balance");
		System.out.println("4.Withdraw data");
		System.out.println("Enter the choice : ");
	
		int choice=s.nextInt();
		switch(choice)
		{	

	case 1:	b1.accept();
	break;
	case 2 :b1.deposit();
	break;
	case 3 :b1.checkbal();
	break; 
	case 4 : b1.withdraw();
	break;
	default : 
		System.out.println("Please enter valid number ");

		}System.out.println("Do you want to continue : ");

		decide=s.next().charAt(0);	

	}while(decide=='y'|decide=='Y');
	
	}

}