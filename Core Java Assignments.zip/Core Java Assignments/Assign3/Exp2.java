class Exp2
{
	public static void main(String hh[])
	{
	byte b,a;
	b=10;
	a=12;
	short c=b+a;
	System.out.println(c);
	}
}