import java.util.*;

class Armstrong
{
	public static void main(String hh[])
	{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Number : ");
	int number=s.nextInt();
	
	int Originalnumber;
	int result=0;
	Originalnumber=number;
	
	while(Originalnumber!=0)
	{
	int digit=Originalnumber%10;
	result=result+(int)(Math.pow(digit,3));
	Originalnumber/=10;

	}
	if(result==number)
	System.out.println("Number is Armstrong");
	else
	System.out.println("Number is Not Armstrong");
	}

}