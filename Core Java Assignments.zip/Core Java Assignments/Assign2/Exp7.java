//	Sort a ten element array in descending order and ascending order.
import java.util.*;
class Exp7
{
	public static void main(String jj[])
	{
	int m;
	Scanner s =new Scanner(System.in);
	
	System.out.println("Enter the no. of Elements in Array : ");
	m=s.nextInt();
	int num[]=new int[m];
	System.out.println("Enter Elements of Array : ");
	
	for (int i=0 ; i<m ; i++)
	{
	num[i]=s.nextInt();
	}
	for(int i=0; i<m ;i++)
	{
		for(int j=i+1;j<m;j++)
		{
		 if(num[i]>num[j])
		 {
		 int temp=num[i];
		 num[i]=num[j];
		 num[j]=temp;
		}
		}
	}
	System.out.println("Ascending Order is : ");
	for(int i=0; i<m;i++)
	System.out.println(num[i]);

	
	System.out.println("Descending Order is : ");
	for(int i=m-1; i>=0;i--)
	System.out.println(num[i]);
		



	}

}