//Write a program to search an element in the array.
import java.util.*;
class Exp9
{
	public static void main(String hh[])
	{int m;
	Scanner s =new Scanner(System.in);
	
	System.out.println("Enter the no. of Elements in Array : ");
	m=s.nextInt();
	int num[]=new int[m];
	System.out.println("Enter Elements of Array : ");
	
	for (int i=0 ; i<m ; i++)
	{
	num[i]=s.nextInt();
	}System.out.println("Elements of Array Are : ");
	for (int i=0 ; i<m ; i++)
	{
	System.out.println(num[i]);	
	}
	System.out.println("Enter search Element in Array : ");
	int search=s.nextInt();
	int count =0;
	for (int i=0 ; i<m ; i++)
	{
		if(search==num[i])
		{
		System.out.println("Elements is Found in Array at position "+(i+1));
		count++;
		}
	}
	if(count==0)
	{
		System.out.println("Elements is Not Found in Array");	
			
	}
	System.out.println("Occurance of no is : "+count);
	}

}