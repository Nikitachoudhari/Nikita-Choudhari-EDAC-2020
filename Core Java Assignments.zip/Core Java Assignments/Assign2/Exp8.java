//Write a program to reverse the array elements.
import java.util.*;
class Exp8
{
	public static void main(String hh[])
	{
	int m;
	Scanner s =new Scanner(System.in);
	
	System.out.println("Enter the no. of Elements in Array : ");
	m=s.nextInt();
	int num[]=new int[m];
	
	System.out.println("Enter Elements of Array : ");
	for (int i=0 ; i<m ; i++)
	{
	num[i]=s.nextInt();
	}
	System.out.println("Reversed array is : ");
	
	 for(int i = m-1; i >= 0; i--)
	{
	System.out.print(num[i] +" ");
	}

          
       
	
	
	}
	
}