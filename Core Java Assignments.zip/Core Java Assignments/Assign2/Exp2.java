//Write a program to reverse a given number.
import java.util.*;
class Exp2
{
	public static void main(String jj[])
	{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the value to be Reversed : ");
	int num=s.nextInt();
	int rev=0;

	for(int i=num ; num>0 ; num/=10)
	{

	int digit=num%10;
	rev = rev*10 +digit;
	}
	System.out.println("Reversed Number is : "+rev);

	}	



}