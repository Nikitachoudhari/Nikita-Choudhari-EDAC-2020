//	Write a program to print table of any entered number using loop.

import java.util.*;
class Exp1
{
	public static void main(String hh[])
	{
	Scanner s = new Scanner(System.in);
	System.out.println("Enter one value : ");
	int a=s.nextInt();
	for (int i=1 ; i<=10 ; i++)
	{
	System.out.println(a+" * "+i+" = "+a*i);
	}
	}

}