//Print all prime numbers between two given numbers. [ break continue ]

import java.util.*;
class Exp5
{
	public static void main(String hh[])
	{
	Scanner s =new Scanner(System.in);
	int start , end;
	System.out.println("Enter the value of start and end : ");
	start=s.nextInt();
	end =s.nextInt();
	int i;
	int flag;
	System.out.println("Prime Numbers Are : ");
	for(i=start ; i<=end ; i++)
	{
		if(i==0 || i==1)
		continue;
		flag=1;
		for(int j=2 ; j<=i/2 ; j++)
		{
			if(i%j == 0 )
			{
			flag=0;
			break;
			}
		}
	
		if(flag==1)
		{
		System.out.println(i);
		}
	}
	
	}

}