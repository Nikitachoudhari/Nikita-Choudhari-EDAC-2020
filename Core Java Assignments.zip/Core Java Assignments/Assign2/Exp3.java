//Program to check whether number is prime or not.
import java.util.*;
class Exp3
{
	public static void main(String hh[])
	{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Number : ");
	int num=s.nextInt();
	int flag=0;
	
	for(int i=2; i<=num/2; i++)
	{
		if(num%i==0)
		{
		flag=1;
		break;
		}
	}
			
		

	if(flag==0)
	{
	System.out.println("Prime Number");
	}else
	System.out.println("Not Prime Number");
	}

}