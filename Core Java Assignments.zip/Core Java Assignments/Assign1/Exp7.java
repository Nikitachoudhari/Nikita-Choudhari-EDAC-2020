//07.	Write a program to calculate sum of 5 subject’s marks & find percentage. Take the obtained marks from user using Scanner class. 
//Output should be in this format [ percentage marks = 99 % ]. Use concatenation operator here.


import java.util.*;
class Exp7
{
	public static void main(String hh[])
	{
	Scanner s= new Scanner(System.in);
	int s1,s2,s3,s4,s5,total;
	System.out.println("Enter the marks of 5 subjects : ");
	s1=s.nextInt();
	s2=s.nextInt();
	s3=s.nextInt();
	s4=s.nextInt();
	s5=s.nextInt();

	total=s1+s2+s3+s4+s5;
	System.out.println("Sum of 5 Subject marks is : "+total);

	float per=total/5;
	System.out.println("Percentage marks = "+per+" %");


	

	}

}