//04.	Write a program that initializes 2 byte type of variables. 
//Add the values of these variables and store in a byte type of variable. [Note: primitive up casting is required in this program ] .

class Exp4
{
	public static void main(String hh[])
	{
	byte b1=10,b2=12;
	int b3=b1+b2;

	System.out.println("Varible is b3 : "+b3);
	
	}

}