//01.	Write a program to print Hello World. Compile and run it using command prompt.

class Exp1
{
	public static void main(String gg[])
	{
	System.out.println("Hello World");
	}
}