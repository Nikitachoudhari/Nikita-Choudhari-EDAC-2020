//Program to find greatest in 3 numbers. [ once using if else statement and then using ternary operator ( logical operator) ] 

import java.util.*;
class Exp13
{
	public static void main(String hh[])
	{
	Scanner s = new Scanner(System.in);
	System.out.print("Enter the First Value : ");
	int a = s.nextInt();
	System.out.print("Enter the Second Value : ");
	int b = s.nextInt();
	System.out.print("Enter the Third Value : ");
	int c = s.nextInt();

	if(a>=b && a>=c)
	{
	System.out.println(a+" is Greater than "+b+" and "+c);
	}
        else if(b>=c)
 	{
	System.out.println(b+" is Greater than "+a+" and "+c);
	}
	else 
       System.out.println(c+" is Greater than "+a+" and "+b);
	


	}
} 