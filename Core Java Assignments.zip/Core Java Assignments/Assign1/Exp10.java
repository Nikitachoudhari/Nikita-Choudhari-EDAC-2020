//10.	Write a program to convert temperature from Fahrenheit to Celsius. Take Fahrenheit as input using Scanner class. [ formula : C= 5*(f-32)/9 ]
import java.util.*;
class Exp10
{
	public static void main(String hh[])
	{
	 double fahrenheit ,celsius ;
	  Scanner s = new Scanner(System.in);

        System.out.print("Input a degree in Fahrenheit: ");
        fahrenheit = s.nextDouble();

        celsius =(( 5 *(fahrenheit - 32.0)) / 9.0);
        System.out.println(fahrenheit + " degree Fahrenheit is equal to " + celsius + " in Celsius");	

	}

}