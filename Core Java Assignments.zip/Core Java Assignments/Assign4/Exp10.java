//10)Find smallest and greatest number in array
import java.util.*;
class Exp10
{
	public static void main(String jj[])
	{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the no of Elements in Array : ");
	int size=s.nextInt();

	int a[]=new int[size];
	System.out.println("Enter the elements in Array : ");
	for(int i=0;i<a.length;i++)
	a[i]=s.nextInt();

	int max=a[0];
	for(int i=1;i<a.length;i++)
	{
	if(a[i]>max)
	max=a[i];
	}
	System.out.println("Greatest Number is : "+max);

	int min=a[0];
	for(int i=1;i<a.length;i++)
	{
	if(a[i]<min)
	min=a[i];
	}
	System.out.println("Smallest Number is : "+min);
	
	
	}

}