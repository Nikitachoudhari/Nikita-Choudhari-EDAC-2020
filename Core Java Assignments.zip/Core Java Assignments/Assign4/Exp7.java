//7)Ascending and Descending order of an array
import java.util.Scanner;
class Exp7
{
	public static void main(String hh[])
	{
	int a[]=new int[5];
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Elements : ");
	for(int i=0;i<5;i++)
	{
	a[i]=s.nextInt();
	}
	
	for(int i=0;i<5;i++)
	{
		for(int j=i+1;j<5;j++)
		{
		if(a[i]>a[j])
		{
		int temp=a[i];
		a[i]=a[j];
		a[j]=temp;
		
		}		
		
		}
	  }System.out.println("Ascending Order is : ");
		for(int k=0;k<5;k++)
		System.out.println(a[k]);

		System.out.println("Descending Order is : ");
		for(int k=4;k>=0;k-- )
		System.out.println(a[k]);

	}
}