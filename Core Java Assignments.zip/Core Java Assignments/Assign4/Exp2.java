//Initialization of Array static , dynamic, memory allocation to array elements

class Exp2
{
	public static void main(String hh[])
	{
	int num[]={10,20,30,40,50};   //static array
	
	int num1[]= new int[4];
	
	num[0]=99;
	num[1]=99;
	num[2]=99;
	num[3]=99;
	
		

	}

}