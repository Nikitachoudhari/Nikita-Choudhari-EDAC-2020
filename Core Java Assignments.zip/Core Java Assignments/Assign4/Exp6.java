//6)Sum of elements in an array and its average
import java.util.Scanner;
class Exp6
{
	public static void main(String hh[])
	{
	int a[]=new int[5];
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Elements : ");
	for(int i=0;i<5;i++)
	{
	a[i]=s.nextInt();
	}
	int sum=0;
	System.out.println("Sum of elelments in Array is : ");
	for(int i=0;i<5;i++)
	sum+=a[i];
	System.out.println("Sum = "+sum);
	System.out.println("Avarage = "+sum/5);

	}
}