//4)Searching an element in array

import java.util.*;
class Exp4
{
	public static void main(String hh[])
	{
	
	Scanner s=new Scanner(System.in);
	int num[]=new int[5];
	System.out.println("Enter the Number in Array : ");
	
	for (int i=0 ; i<5 ; i++)
	{
	num[i]=s.nextInt();
	}
	System.out.println("Enter the search Element : ");
	int serch=s.nextInt();
	int flag=0;
	for (int i=0 ; i<5 ; i++)
	{

		if(serch==num[i])
		{flag=1;
		
		}	

	}
	if(flag==0)
	System.out.println("Element is Not found");
	else
System.out.println("Element is found");

	
	
	}

}