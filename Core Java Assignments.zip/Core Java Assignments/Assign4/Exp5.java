//5)Reversing a array and print it

import java.util.*;
class Exp5
{
	public static void main(String hh[])
	{
	Scanner s=new Scanner(System.in);
	int num[]=new int[10];
	System.out.println("Enter the elements in Array : ");
	for(int i=0 ; i<10 ; i++)
	{
	num[i]=s.nextInt();
	}

	System.out.println("Reversed Array is :");
	for(int j=9 ; j>0 ; j--)
	{
	System.out.println(num[j]);
	}

	}
}