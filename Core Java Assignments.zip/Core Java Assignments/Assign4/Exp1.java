//1)Declare An Array  int, double, float

class Exp1
{
	public static void main(String hh[])
	{
	int a1[];    //declaration of array
	double a2[];
	float a3[];

	
	}
}
