//4.	Create a class MathOperation containing overloaded methods ‘multiply’ to calculate multiplication of following arguments. 
//a.	 two integers 
//b.	 three floats 
//c.	 all elements of array 
//d.	one double and one integer 


class MathOperation
{
	void multiply(int  a,int b)
	{
		System.out.println("Multiplication of 2 integer nos . : "+a*b);	
	}
	void multiply(float  a, float b,float c)
	{
		System.out.println("Multiplication of 3 float nos . : "+a*b*c);	
	}
	void multiply(int  a,double b)
	{
		System.out.println("Multiplication of 1 integer and 1 double nos . : "+a*b);	
	}
	void multiply(int b[])
	{	int mul=1;
		for(int i=0 ; i<b.length;i++)
		{
			mul=mul*b[i];
		}
		System.out.println("Multiplication of array is : "+mul);	
	}


}
class Exp4
{
	public static void main(String hh[])
	{
		MathOperation m1=new MathOperation();
		m1.multiply(10,22);
		m1.multiply(10.22f,11.3f,63.24f);
		m1.multiply(15,10.22);

		int a[]={12,52,41,2};
		m1.multiply(a);

	}
}
