//08.	Create three classes
//-	Faculty with two data members facultyId and salary and two methods, one intput() method for accepting facultyId as input and another printSalary() to 
//print salary.
//-	FullTimeFaculty that inherits class Faculty with two data members’ basicSalary and allowance. Override input() method in this class that calls super 
//class inut() method and accepts basicSalary and allowance as input. Salary should not be accepted as input but should be calculated using formula 
//(basicSalary + allowance)
//-	PartTimeFaculty that inherits class Faculty with two data members’ workingHours, ratePerHour. Override input() method in this class that 
//calls super class inut() method and accepts workingHours and ratePerHour as input. Salary should not be accepted as input but should be calculated using formula 
//( workingHour * ratePerHour )

import java.util.*;
class Faculty
{ Scanner s=new Scanner(System.in);
	int facultyId;
	double salary;

	void input()
	{
		System.out.println("Enter faculty ID : ");
		facultyId= s.nextInt();	
		System.out.println("Enter Salary : ");
		salary= s.nextDouble();	
	}

	void printSalary()
	{
		System.out.println("Salary Faculty is : "+salary);
	}
}

class FullTimeFaculty extends Faculty
{
	double basicSalary;
	int allowance;
	
	void input()
	{
		super.input();	
		System.out.println("Enter BasicSalary : ");
		basicSalary= s.nextDouble();
		System.out.println("Enter Allowance : ");
		allowance= s.nextInt();
	}
	void printSalary()
	{
		salary= basicSalary + allowance;
		System.out.println("Salary of Full Time Faculty  is : "+salary);
	}
	
	
}

class PartTimeFaculty extends Faculty
{
	int  workingHours;
	Double ratePerHour;

	void input()
	{
		super.input();	
		System.out.println("Enter working Hours : ");
		workingHours= s.nextInt();
		System.out.println("Enter rate Per Hour : ");
		ratePerHour= s.nextDouble();
	}
	void printSalary()
	{
		salary= workingHours * ratePerHour;
		System.out.println("Salary of Part Time Faculty  is : "+salary);
	}


		
}

class Exp8
{
	public static void main(String hh[])
	{
		FullTimeFaculty f1=new FullTimeFaculty();
		f1.input();
		f1.printSalary();

		PartTimeFaculty p1=new PartTimeFaculty();
		p1.input();
		p1.printSalary();
	}
}


