//06.	Create class Product with three data members (pid, price, quantity) and parameterized constructor that takes values for all three data members.  
//Create a main method in different class (say ProductDemo) and perform following task:
//a. Accept information for five Product objects from user and store objects in an array
//b. Find pid of product with highest price. 
//c. Create a static method (with array of product’s object as argument) in Product class to calculate and return total amount spent on all products. 
//( amount spent on single product = price of product * quantity of product )

import java.util.*;
class Product
{	Scanner s=new Scanner(System.in);
	int pid;
	double price;
	int quantity;

	Product(int pid , double price , int quantity)  //Parameterized constructor
	{
		this.pid = pid;
		this.price = price;
		this.quantity = quantity;
	}

	public void display()
	{
	System.out.println("Pid : "+pid+ " Price : " +price+ " Quantity : "+ quantity);	
	}
	
	
	static double Amount(double price , int quantity)
	{
		
		double amt = price * quantity;
		return amt;
	}

}

class Exp6
{
	public static void main(String hh[])
	{
		Scanner sc = new Scanner(System.in);
		int pid=0;
		double price=0;
		int quantity=0;
		System.out.println("Please enter no. of Products:");
		int size = sc.nextInt();
		Product p[] =  new Product[size];	
			
		
	
	// . Accept information for five Product objects from user and store objects in an array.
		

		for(int i=0 ; i<p.length ; i++)
		{
			System.out.println("Enter PID : ");
			pid=sc.nextInt();
 
			System.out.println("Add price : ");
			price=sc.nextDouble();
			
			System.out.println("Add Quantity : ");
			quantity=sc.nextInt();
			
			p[i] = new Product(pid,price,quantity);	
		}
		
		for(int i=0;i<p.length;i++) 
		{
			p[i].display();
				
		}
		
		// b. Find pid of product with highest price. 

		double max = 0.0;
		int key=0;
		for(int i=0 ; i<p.length ; i++)
		{
			
			if(p[i].price>max)
			{
				max=p[i].price;	
				key=i;
			}
		}
		
		  System.out.println("PID : "+p[key].pid+" Max Price: "+max);
				
				

// Create a static method (with array of product’s object as argument) in Product class to calculate and return total amount spent on all products. ( 
//amount spent on single product = price of product * quantity of product )

		for(int i=0;i<p.length;i++)
		{
			System.out.println("Amount of Product : "+p[i].Amount(p[i].price,p[i].quantity));
		}

	}
}
