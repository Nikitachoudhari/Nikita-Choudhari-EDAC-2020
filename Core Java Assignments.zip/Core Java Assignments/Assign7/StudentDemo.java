//1.Create a class Student with 2 data members rollno and name. Create one method setData() that takes roll number and student name as 
//parameter and stores them in data members rollno and name. Create one more method showData() to print the data member values.
// Create another class ( main class) StudentDemo that creates Student class object and calls setData() and showData() methods.


class Student
{
	int rollno;
	String name;

	void setData(int r, String n)
	{
		rollno=r;
		name=n;
	
	}

	void showData()
	{
		System.out.println("Student Roll number is : "+rollno);
		System.out.println("Student Name is : "+name);
		
	}

}

class StudentDemo
{
	public static void main(String hh[])
	{	

	Student s1=new Student();
	s1.setData(12, "Nikita Choudhari");
	s1.showData();

}}