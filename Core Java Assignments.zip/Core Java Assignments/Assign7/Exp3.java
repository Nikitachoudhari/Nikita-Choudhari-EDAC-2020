//3.	Create a class MathOperation that has four static methods. add() method that takes two integer numbers as parameter and returns the sum of the numbers.
// subtract() method that takes two integer numbers as parameter and returns the difference of the numbers. multiply() method that takes two integer numbers
// as parameter and returns the product. power() method that takes two integer numbers as parameter and returns the power of first number to second number. 
//Create another class Demo (main class) that takes the two numbers from the user and calls all four methods of MathOperation class by providing entered
// numbers and prints the return values of every method.

import java.util.*;
class MathOperation
{
	static int add(int a,int b)
	{
		return a+b;	
	}
	static int subtract(int a,int b)
	{
		return a-b;	
	}
	static int multiply(int a,int b)
	{
		return a*b;	
	}
	static int power(int a,int b)
	{
		return (int)(Math.pow(a,b));	
	}
}
class Exp3
{
	public static void main(String hh[])
	{
		Scanner s1=new Scanner(System.in);
		System.out.print("Enter the two Numbers : ");
		int x=s1.nextInt();
		int y=s1.nextInt();
	
		System.out.println("Addition is : "+MathOperation.add(x,y));
		System.out.println("Subtraction is : "+MathOperation.subtract(x,y));
		System.out.println("Multiplication is : "+MathOperation.multiply(x,y));
		System.out.println("power of first number to second number is : "+MathOperation.power(x,y));

	
	
	}
}