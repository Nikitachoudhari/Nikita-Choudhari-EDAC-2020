//5)WAP to define Class Simpleinterest with attributes principalamount,  rate of interest static ,number of years calculate SI and display it.

class Simpleinterest
{
	float principalamount,rateOfInterest,Time,sInterest ;
	
	
	Simpleinterest(float p,float r,float t)
	{
	principalamount=p;
	rateOfInterest=r ;
	Time=t;

	}

	void sInterest()
	{
	sInterest=(principalamount*rateOfInterest *Time)/100;
	}
	void display()
	{
	System.out.println("Simple Interest is : "+sInterest);
	}	

}

class Exp5
{
	public static void main(String hh[])
	{
	Simpleinterest s=new Simpleinterest(2000,6,3);
	s.sInterest();
	s.display();
	
	}

}