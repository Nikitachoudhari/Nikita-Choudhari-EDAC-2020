//WAP to define a class Book with Attributes id,name,price accept data for 5 objects display book with highest price.
import java.util.*;
class Book
{Scanner s=new Scanner(System.in);
	int bookId;
	String name;
	int price;
	
	void accept()
	{
	System.out.print("Enter book Id : ");
	bookId=s.nextInt();
	System.out.print("Enter Name : ");
	s.next();
	name=s.nextLine();
	System.out.print("Enter Price : ");
	price=s.nextInt();
	}
	
	void display()
	{
	System.out.println("Book ID : "+bookId);
	System.out.println("Book Name : "+name);
	System.out.println("Book Price : "+price);
	}

}
class Exp2
{
	public static void main(String gg[])
	{
	Book b1[]=new Book[5];     //Array of reference
	
	
	b1[0]=new Book();
	b1[1]=new Book();
	b1[2]=new Book();
	b1[3]=new Book();
	b1[4]=new Book();
	
	for(int i=0;i<5;i++)
	{System.out.println("Enter data of "+i+" Book");
	b1[i].accept();
	}
	System.out.println("Book with Highest Price is : ");
	int max=0,key=0;
	for(int i=0;i<5;i++)
	if(b1[i].price>max)
	{
	max=b1[i].price;
	key=i;
	}b1[key].display();

	}
}



