class Test1
{
	public static void main(String aa[])
	{
	Test1 t1=new Test1();
	System.out.println(t1);
	}
}
