//8)Accept 2 array from user and display its sum in third array
import java.util.*;
class Exp8
{
	public static void main(String hh[])
	{Scanner s=new Scanner(System.in);
	int size=s.nextInt();
	
	int num1[]=new int[size];
	int num2[]=new int[size];
	int num3[]=new int[size];
	

	System.out.println("Enter the elements  of first Array : ");
	for (int i=0;i<num1.length;i++)
	{
	num1[i]=s.nextInt();
	}

	System.out.println("Enter the elements  of Second Array : ");
	for ( int j=0;j<num2.length;j++)
	{
	num2[j]=s.nextInt();
	}

	System.out.println("Third Array is : ");
	for (int k=0;k<num3.length;k++)
	{
	num3[k]=num1[k]+num2[k];
	System.out.println(num3[k]);
	}

	}

}