//3)Take input from user for an array
import java.util.*;

class Exp3
{
	public static void main(String hh[])
	{
	Scanner s=new Scanner(System.in);
	int num[]=new int[5];
	System.out.println("Enter the Number : ");
	for (int i=0 ; i<5 ; i++)
	{
	num[i]=s.nextInt();
	}System.out.println("------------------------------");
	for (int i=0 ; i<5 ; i++)
	{
	System.out.println(num[i]);
	}
		
	}
}