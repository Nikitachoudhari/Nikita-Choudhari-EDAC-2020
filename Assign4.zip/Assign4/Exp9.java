//9)Accept 2 array from user and display its product in third array
import java.util.*;
class Exp9
{
	public static void main(String jj[])
	{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the size of Array : ");
	int size=s.nextInt();
	
	int num1[]=new int[size];	
	int num2[]=new int[size];
	int num3[]=new int[size];

	System.out.println("Enter the Elements of first Array : ");
	for(int i=0;i<size;i++)
	num1[i]=s.nextInt();

	
	System.out.println("Enter the Elements of Second Array : ");
	for(int j=0;j<size;j++)
	num2[j]=s.nextInt();

	System.out.println("Third Array of Product is : ");
	for(int k=0;k<size;k++)
	{
	num3[k]=num1[k]*num2[k];
	System.out.println(num3[k]);
	}

	
	


	}

}