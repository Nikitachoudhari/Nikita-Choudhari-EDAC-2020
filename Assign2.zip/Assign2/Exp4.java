//Calculate  series : 12+22+32+42+.........+n2

import java.util.*;
class Exp4
{
	public static void main(String jj[])
	{
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the Number : ");
	int num=s.nextInt();
	int sum=0;
	System.out.println("===============");
	for (int i=12 ; i<=num ; i+=10)
	{
	System.out.println(i);
	sum=sum+i;
	}
	System.out.println("Sum of series is : "+sum);
	}

}