//Write the program to find the sum of even elements and sum of odd elements present in the array of integer type.
import java.util.*;
class Exp10
{
	public static void main(String hh[])
	{
	int m;
	int sum=0 ,sum1=0;
	Scanner s =new Scanner(System.in);
	
	System.out.println("Enter the no. of Elements in Array : ");
	m=s.nextInt();
	int num[]=new int[m];

	System.out.println("Enter Elements of Array : ");
	for (int i=0 ; i<m ; i++)
	{
	num[i]=s.nextInt();
	}
	for (int i=0 ; i<m ; i++)
	{
	 	if(num[i]%2==0)
		{
		sum=sum+num[i];
		}else
		sum1=sum1+num[i];
		
	}
	System.out.println("Sum of Even numbers is : "+sum);
	System.out.println("Sum of Odd numbers is : "+sum1);
	

	}
}