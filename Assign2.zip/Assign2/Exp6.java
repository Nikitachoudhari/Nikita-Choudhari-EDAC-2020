//Program to show sum and average of 10 element array. Accept array elements from user.
import java.util.*;
class Exp6
{
	public static void main(String hh[])
	{
	int num[]=new int[10];
	int sum=0;
	Scanner s = new Scanner(System.in);
	System.out.println("Enter 10 values : ");
	for (int i=0 ; i<=9 ; i++)
	{
	num[i]=s.nextInt();
	sum=sum+num[i];
	}
	System.out.println("Sum of Number is : "+sum);
	float avg=sum/10;
	
	System.out.println("Averahe of Number is : "+avg);

	}

}