//Find the result of following expressions. You need to determine the primitive data type of the variable by looking carefully the given expression and initialize
// variables by any random value.
//A. y = x2 + 3x - 7 (print value of y) 
//B. y = x++ + ++x (print value of x and y) 
//C. z = x++ - --y - --x  +  x++ (print value of x ,y and z)
//D. z = x && y || !(x || y)  (print value of z) [ x, y, z are boolean variables ]   

import java.util.*;
class Test
{
	void f1(int x)
	{
	int y = (int)(Math.pow(x,2)) + 3*x - 7 ;
	System.out.println(y);
	}
	
	void f2(int x )
	{
	int y = x++ + ++x ;
	System.out.println(x);
	System.out.println(y);
	}

	void f3(int x , int y)
	{
	int z = x++ - --y - --x  +  x++ ;
	System.out.println(x);
	System.out.println(y);
	System.out.println(z);
	}

	void f4(boolean x,boolean y)
	{
	boolean z = x && y || !(x || y) ;
	System.out.println(z);
	}
	

}
class Exp3
{
	public static void main(String hh[])
	{
	System.out.println("Enter Numbers : ");	
	Scanner s = new Scanner(System.in);

	int x = s.nextInt();
	int y = s.nextInt();	
	boolean a = s.nextBoolean();
	boolean b = s.nextBoolean();	
	
	Test t1= new Test();
	System.out.println("-----------------------");
	t1.f1(x);
	System.out.println("-----------------------");
	t1.f2(x);
	System.out.println("-----------------------");
	t1.f3(x,y);
	System.out.println("-----------------------");
	t1.f4(a,b);
	
	
	
	
	
	
	}

}
