//09.	Write a program to read the days (eg. 670 days) as integer value using Scanner class.
// Now convert the entered days into complete years, months and days and print them.

import java.util.*;
class Exp9
{
	public static void main(String hh[])
	{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the no. of Days : ");
	int days=s.nextInt();
	
	int year=(days/365);
	days=(days%365);
	System.out.println("No. of year : "+year);

	int month=(days/30);
	days=(days%30);
	System.out.println("No. of months : "+month);

	int week =(days/7);
	days=(days%7);
	System.out.println("No. of Week : "+week);


	int day=days;
	System.out.println("No. of Days : "+day);



	}
}