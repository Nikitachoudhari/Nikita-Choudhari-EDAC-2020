//15.	Accept person’s gender (character m for male and f for female), age (integer), as input and then check whether person is eligible for marriage or not.

import java.util.*;
class Exp15
{
	public static void main(String hh[])
	{
	Scanner scan =new Scanner(System.in);
	System.out.println("Enter person's gender m for male and f for female : ");
	char c = scan.next().charAt(0);

	System.out.println("Enter person's age : ");
	int age = scan.nextInt();

	if(c =='m')
	{
	 	if(age>=21)
	 	{
	 	System.out.println("Person is Eligible for marriage ");
	 	}
		else
		{
		 System.out.println("Person is Not Eligible for marriage ");
		}
	
	}else if(age>=18)
	  	 {
	  	 System.out.println("Person is Eligible for marriage ");
	 	 }
		else
		System.out.println("Person is Not Eligible for marriage ");
	
	   
	

	}

}