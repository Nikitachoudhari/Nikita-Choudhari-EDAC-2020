//06.	Write a program that takes radius of a circle as input. Read the entered radius using Scanner class. 
//Then calculate and print the area and circumference of the circle

import java.util.*;
class Exp6
{
	public static void main(String hh[])
	{
	double radius,area,circum;
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the Radius of Circle : ");
	radius=s.nextDouble();
	area=3.14*radius*radius;
	circum=2*3.14*radius;

	System.out.println("Area of Circle : "+area);
	System.out.println("Circumference of Circle : "+circum);
	
		

	}
}