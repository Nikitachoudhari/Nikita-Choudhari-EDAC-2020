//05.	Write a program that takes user’s name as command line argument and prints Welcome <entered user name>.

class Exp5
{
	public static void main(String hh[])
	{
	String str = hh[0];
	System.out.println("Welcome "+str);
	}

}
