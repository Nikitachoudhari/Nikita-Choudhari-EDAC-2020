//14.	Program to check that entered year is a leap year or not.

import java.util.*;

class Exp14
{
	public static void main(String hh[])
	{
	Scanner s =new Scanner(System.in);
	System.out.println("Enter the Year : ");
	int year = s.nextInt();
	if(year % 400 ==0)
	{
	System.out.println("Leap year");
	}
	else if(year %4 ==0 && (year% 100)!=0 )
	{
	System.out.println("Leap year");
	}
	else
	{
	System.out.println("Not Leap year");
	}


	}

}