//12.	In a company an employee is paid as under: If his basic salary is less than Rs. 10000, then HRA = 10% of basic salary and DA = 90% of basic salary.
// If his salary is either equal to or above Rs. 10000, then HRA = Rs. 2000 and DA = 98% of basic salary. 
//If the employee's salary is input by the user write a program to find his gross salary. [ formula : GS= Basic + DA + HRA ]

import java.util.*;
class Exp12
{
	public static void main(String jj[])
	{
	float Basic,DA ,HRA ,GS;
	Scanner s = new Scanner(System.in);
	System.out.println("Enter your Salary : ");
	Basic =s.nextFloat();

	if(Basic<10000)
	{
	HRA=Basic*10/100;
	DA=Basic*90/100;
	}else
	{
	HRA=2000;
	DA=Basic*98/100;
	}

	GS= Basic + DA + HRA ;

	System.out.println("DA : "+DA);
	System.out.println("HRA : "+HRA);
	System.out.println("Gross Salary : "+GS);

	}


}