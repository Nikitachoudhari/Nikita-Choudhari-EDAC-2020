//11.	Write a program to swap two numbers without using third variable.

class Exp11
{
	public static void main(String hh[])
	{
	int a=5, b=3;      
        System.out.println("Before swap a= "+a+" b= "+b);      
	a=a+b;  //a=5+3=8  
	b=a-b; //b=5 (8-3)    
	a=a-b; //a=3 (8-5)    
	System.out.println("After swap a= "+a+" b= "+b);       
 
	}
}