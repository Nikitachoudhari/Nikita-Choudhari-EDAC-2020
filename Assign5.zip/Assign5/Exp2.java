// 2.Write a program which takes an array of integers and prints the running average of 3 consecutive integers. 
//In case the array has fewer than 3 integers, there should be no output. 
// Input: [5,14,35,89,140] Output: [18, 46, 88]  (Explanation: 18=(5+14+35/3, 46=(14+35+89)/3, ...) 

import java.util.*;
class Exp2
{
	public static void main(String gg[])
	{
	Scanner s=new Scanner(System.in);
	
	System.out.println("Enter the no of elements of Array : ");
	int n=s.nextInt();
	
	int a[]=new int[n];
	int b[]=new int[n-2];
	System.out.println("Enter the elements : ");
	for(int i=0;i<a.length;i++)
	a[i]=s.nextInt();

	for(int i=0;i<n-2;i++)
	b[i]=(a[i]+a[i+1]+a[i+2])/3;

	System.out.println("new Array is  : ");
	for(int i=0;i<n-2;i++)
	System.out.println(b[i]);
	
	
	}

}