//4.Given an array of integers, print whether the numbers are in ascending order or in descending order or in random order without sorting  
//Input: [5,14,35,90,139] Output: Ascending   
//Input: [88,67,35,14,-12] Output: Descending
// Input: [65,14,129,34,7] Output: Random 

import java.util.*;
class Exp4
{
	public static void main(String hh[])
	{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the no of elements : ");
	int n=s.nextInt();
	
	int a[]=new int[n];
	System.out.println("Enter the Elements of Array : ");
	for (int i=0;i<n;i++)
	a[i]=s.nextInt();
	
	int flag=0;
	
	for(int j=0;j<n-1;j++)
	{
	if(a[j]>a[j+1])
	flag=1;
	}
	if(flag==1)
	System.out.println("Ascending");
	else
	System.out.println("Descending");
		
	}

}