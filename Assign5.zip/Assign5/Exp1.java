//1. Write a program to merge two arrays of integers by reading one number at a time from each array until  one of the array is exhausted, and 
//then concatenating the remaining numbers. 
// Input: [23,60,94,3,102] and [42,16,74]  Output: [23,42,60,16,94,74,3,102]   

import java.util.*;
class Exp1
{
	public static void main(String gg[])
	{
	Scanner s=new Scanner(System.in);
	//first Array
	System.out.print("Enter the size of first Array : ");
	int n=s.nextInt();
	int a[]=new int[n];
	System.out.println("Enter the Elements of Array : ");
	for(int i=0;i<a.length;i++)
	a[i]=s.nextInt();

	//Second Array
	System.out.print("Enter the size of Second Array : ");
	int m=s.nextInt();
	int b[]=new int[m];
	System.out.println("Enter the Elements of Array : ");
	for(int j=0;j<b.length;j++)
	a[j]=s.nextInt();
	
	int k;
	int c[]=new int[n+m];
	for(k=0; k<n ;k++)
	{
	c[k]=a[k++];
	}
	for( k=0; k<m ;k++)
	{
	c[k]=b[++k];
	}
	for(int x=0;x<n+m;x++)
	System.out.println(c[0]);
	
	}

}