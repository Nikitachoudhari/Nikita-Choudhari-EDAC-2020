//3. Write a program which generates the series 1,4,27,16,125,36 .
import java.util.*;
class Exp3
{
	public static void main(String hh[])
	{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Number : ");
	int n=s.nextInt();

	for( int i=1;i<n+1;i++)
	{
	if(i%2==0)
	System.out.print(i*i+" ");
	else
 	System.out.print(i*i*i+" ");
	}
	}

}  
 