//09.	Create an Abstract class Processor with int member variable data  and method showData to display data value. Create abstract method process() to
// define processing of member data. Create a class  Factorial using abstract class Processor  to calculate and print factorial of a number by overriding the process
// method. 
//b. Create a class Circle using abstract class Processor to calculate and print area of a circle by overriding the process method.
//Ask user to enter choice (factorial or circle area).  Also ask data to work upon. Use Processor class reference to achieve this mechanism.

import java.util.*;
abstract class Processor
{Scanner s =new Scanner(System.in);
	int data;

	void showData()
	{
		System.out.println("Data is : "+data);
	}
	abstract void process();
}

class  Factorial extends Processor
{
	void process()
	{
		System.out.println("Enter the data value to calculate factorial : ");	
		data=s.nextInt();
		int fact=1;
		for (int i=1 ; i<=data ; i++)
		fact=fact*i;
		System.out.println("Factorial of "+data+" is : "+fact);
	
	}
}

class  Circle extends Processor
{
	void process()
	{
		System.out.println("Enter the radius of Circle : ");	
		data=s.nextInt();
		double area=3.14*data*data;
		System.out.println("Area of Circle is : "+area);
	}
}

class Exp9
{
	public static void main(String hh[])
	{Scanner s =new Scanner(System.in);

		System.out.println("Enter your Choice : ");
		System.out.println("1. factorial : ");
		System.out.println("2. Area of Circle : ");
		int choice =s.nextInt();
		
	switch(choice)
	{
		case 1 :Factorial f1=new Factorial();
		        f1.process();
			break;
		
		case 2 : Circle c1=new Circle();
		        c1.process();
			break;

		default : System.out.println("Enter valid choice");	

		
	}}
}

 