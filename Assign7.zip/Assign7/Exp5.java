//5.	Create a class Employee with three data members (empNo, salary and totalSalary) and following features.
//a.	Only parameterized constructor. [Do not overload the constructor]
//b.	totalSalary always represents salary total of all the employees created.
//c.	empNo should be auto incremented.
//d.	display total employees and totalSalary using a method.
//Create another class EmployeeDemo (main class) that creates some Employee objects and calls Employee method to display no. of employees and total of their salaries.

import java.util.*;
class Employee
{
	int empNo;
	double salary;
	double totalSalary;

	Employee(int empNo , double salary )
	{
		this.empNo=empNo;
		this.salary=salary;
			
	}
	
	void Display()
	{
		System.out.println("Employee id : "+empNo+" Employee Salary : "+salary);
		
	}
	

}
class Exp5
{
	public static void main(String  hh[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the no. of Employee : ");
		int size = s.nextInt();
			
		int pid=0;
		double salary=0.0;
		
		Employee e1[]=new Employee[size];
		for(int i=0 ; i<e1.length ; i++)
		{
			System.out.println("Enter Employee id : ");
			pid=s.nextInt();

			System.out.println("Enter Employee Salary : ");
			salary=s.nextDouble();

			e1[i]=new Employee( pid , salary  );
		}
		
		
				
		for(int i=0 ; i<e1.length ; i++)
		{
			
			e1[i].Display();
		}
	
		double total=0.0;
		for(int i=0 ; i<e1.length ; i++)	
		total = total+e1[i].salary;
		System.out.println("Total Salary : "+total);
			
		

	}

}